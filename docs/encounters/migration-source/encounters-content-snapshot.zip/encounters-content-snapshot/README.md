# Encounters Again and Again — content snapshot

Migration-ready snapshot captured from `https://encountersagainandagain.com` on 2026-09-12T01:38:28.372317+00:00.

## Contents

- `seed-content.json`: canonical structured snapshot for future transformation into a database seed.
- `content-blocks.csv`: flattened editorial-block inventory for review in a spreadsheet.
- `image-inventory.csv`: image source, local file, size, dimensions and usage.
- `assets/images/`: downloaded images referenced by the public pages and page sitemap.
- `raw/`: original WordPress REST responses used to generate the snapshot.

## Snapshot totals

- Pages: 11
- Stories/posts: 1
- Referenced images: 50
- Failed image downloads: 0

## Important rules

1. Text is stored verbatim. Spelling, punctuation and grammar were not corrected.
2. `migration_status` distinguishes core content from legacy/system/future-disabled content.
3. `proposed_path` is only a migration suggestion; the source URL remains authoritative.
4. Each content item preserves ordered `blocks`, page-level `links`, page-level `images`, and local image paths.
5. This is a content snapshot, not a final SQL seed. Transform it after the destination schema is finalized.

## Suggested destination entities

- `pages`
- `projects`
- `stories`
- `team_members`
- `content_blocks`
- `media_assets`
- `content_media`
- `external_links`

The current WordPress names and technical slugs should not be used as permanent database concepts.
